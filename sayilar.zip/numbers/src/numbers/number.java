package numbers;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
public class number {

       public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		List<String> list= new ArrayList<String>();
		List<Integer> sayi=new ArrayList<Integer>();
		System.out.println("Give me a number for getting factorial");
		int fact=sc.nextInt();
		int mresult=factorial(fact);
		System.out.println("Girilen sayinin faktoriyeli= "+mresult);
		int biggest=0;
		int lowest=999999999;
		while(true) {
			System.out.println("Büyük ve küçük bulmak için sayi giriniz son sayiyi girdikten sonra menüden cikmak için 0 yaziniz");
			int gnumb=sc.nextInt();	
			if(gnumb>biggest) {
				biggest=gnumb;
			}
			if(lowest>gnumb && gnumb>0) {
				lowest=gnumb;
			}
			if(gnumb==0) {
				System.out.println("En büyük " +biggest);
				System.out.println("En küçük = "+lowest);
				break;
			}
		}
		System.out.println("bitti");
		
		
		
		
		
       }
	public static Integer factorial(int fnumb){
		int result=1;
		for(int i=1;i<=fnumb;i++) {
			result=result*i;
		}
		return result;
	}

}




