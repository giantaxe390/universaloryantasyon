package numbers;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
public class number {

       public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		List<String> list= new ArrayList<String>();
		List<Integer> sayi=new ArrayList<Integer>();
		System.out.println("Give me a number for getting factorial");
		int fact=sc.nextInt();
		int mresult=factorial(fact);
		System.out.println("Girilen sayinin faktoriyeli= "+mresult);
		int biggest=0;
		int lowest=99999;
		int opp;
		while(true) {
			System.out.println("Büyük ve küçük bulmak için sayi giriniz son sayiyi girdikten sonra menüden cikmak için 0 yaziniz");
			int gnumb=sc.nextInt();	
			if(gnumb!=0) {
				sayi.add(gnumb);	
			}
			
			if(gnumb>biggest) {
				biggest=gnumb;
			}
			if(lowest>gnumb && gnumb>0) {
				lowest=gnumb;
			}
			if(gnumb==0) {
				System.out.println("En büyük " +biggest);
				System.out.println("En küçük = "+lowest);
				break;
			}
		}
		System.out.println("bitti");
		for(int i=0;i<sayi.size();i++) {
			for(int j=i+1;j<sayi.size();j++) {
				if(sayi.get(j)<sayi.get(i)) {
					opp=sayi.get(i);
					sayi.set(i, sayi.get(j));
					sayi.set(j, opp);
				}
			}
		}
		System.out.println(sayi);
		System.out.println("en küçük= "+sayi.get(0));
		System.out.println("en büyük= "+sayi.get(sayi.size()-1));	
       }
	public static Integer factorial(int fnumb){
		int result=1;
		for(int i=1;i<=fnumb;i++) {
			result=result*i;
		}
		return result;
	}

}




